"""Train the baseline NIDS model and save its metrics."""
import argparse
import json
from pathlib import Path
import joblib
from src.data_loader import load_dataset
from src.preprocessing import split_features_and_labels
from src.model import build_model, evaluate_model

def train(dataset_path, model_path, metrics_path):
    df = load_dataset(dataset_path)
    X_train, X_test, y_train, y_test = split_features_and_labels(df)
    model = build_model()
    model.fit(X_train, y_train)
    metrics = evaluate_model(model, X_test, y_test)
    Path(model_path).parent.mkdir(parents=True, exist_ok=True)
    Path(metrics_path).parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, model_path)
    with open(metrics_path, "w", encoding="utf-8") as handle:
        json.dump(metrics, handle, indent=2)
    return metrics

def main():
    parser = argparse.ArgumentParser(description="Train a baseline network intrusion detector.")
    parser.add_argument("--data", default="data/sample_network_flows.csv")
    parser.add_argument("--model", default="models/nids_model.joblib")
    parser.add_argument("--metrics", default="reports/metrics.json")
    args = parser.parse_args()
    metrics = train(args.data, args.model, args.metrics)
    print(json.dumps({k: v for k, v in metrics.items() if k != "classification_report"}, indent=2))
    print(f"\nSaved model to {args.model} and metrics to {args.metrics}")

if __name__ == "__main__":
    main()
