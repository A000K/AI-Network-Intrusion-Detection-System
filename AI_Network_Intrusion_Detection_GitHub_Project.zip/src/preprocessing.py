"""Feature/label separation and reproducible data splitting."""
from sklearn.model_selection import train_test_split

def split_features_and_labels(df, label_column="label", test_size=0.2, random_state=42):
    """Split labelled data into train and test partitions.

    This starter project expects numeric feature columns. Remove identifiers,
    timestamps, and any target-leaking columns before training.
    """
    if label_column not in df.columns:
        raise ValueError(f"Label column not found: {label_column}")
    if df[label_column].isna().any():
        raise ValueError("Label column contains missing values.")
    X = df.drop(columns=[label_column])
    y = df[label_column]
    if X.shape[1] == 0:
        raise ValueError("Dataset contains no feature columns.")
    return train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )
