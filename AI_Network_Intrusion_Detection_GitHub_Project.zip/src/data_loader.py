"""Dataset loading and validation helpers for the NIDS project."""
from pathlib import Path
import pandas as pd

REQUIRED_COLUMNS = {"flow_duration", "packet_count", "label"}

def load_dataset(file_path: str | Path) -> pd.DataFrame:
    """Load a CSV file and validate the minimum required schema."""
    path = Path(file_path)
    if not path.is_file():
        raise FileNotFoundError(f"Dataset not found: {path}")
    try:
        df = pd.read_csv(path)
    except (pd.errors.ParserError, UnicodeDecodeError, OSError) as exc:
        raise ValueError(f"Could not read CSV dataset: {exc}") from exc
    validate_network_data(df)
    return df

def validate_network_data(df: pd.DataFrame) -> pd.DataFrame:
    """Check required columns and reject empty datasets."""
    missing = REQUIRED_COLUMNS - set(df.columns)
    if missing:
        raise ValueError(f"Dataset is missing required columns: {', '.join(sorted(missing))}")
    if df.empty:
        raise ValueError("Dataset contains no records.")
    if df["label"].isna().any():
        raise ValueError("Label column contains missing values.")
    return df
