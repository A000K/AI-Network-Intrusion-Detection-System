"""Load a trained model and classify new numeric network-flow records."""
import argparse
import joblib
import pandas as pd

def main():
    parser = argparse.ArgumentParser(description="Predict benign/attack labels from a CSV.")
    parser.add_argument("--model", default="models/nids_model.joblib")
    parser.add_argument("--input", required=True, help="CSV with the same feature columns used in training")
    parser.add_argument("--output", default="reports/predictions.csv")
    args = parser.parse_args()
    model = joblib.load(args.model)
    df = pd.read_csv(args.input)
    predictions = model.predict(df)
    result = df.copy()
    result["predicted_label"] = predictions
    if hasattr(model, "predict_proba"):
        try:
            result["confidence"] = model.predict_proba(df).max(axis=1)
        except (ValueError, AttributeError):
            pass
    from pathlib import Path
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(args.output, index=False)
    print(f"Saved predictions for {len(result)} records to {args.output}")

if __name__ == "__main__":
    main()
