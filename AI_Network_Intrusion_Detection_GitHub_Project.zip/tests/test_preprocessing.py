import pandas as pd
import pytest
from src.preprocessing import split_features_and_labels

def test_split_keeps_rows_and_label_separate():
    df = pd.DataFrame({
        "flow_duration": list(range(20)),
        "packet_count": list(range(100, 120)),
        "label": ["benign", "attack"] * 10,
    })
    X_train, X_test, y_train, y_test = split_features_and_labels(df)
    assert len(X_train) + len(X_test) == len(df)
    assert "label" not in X_train.columns
    assert len(y_train) == len(X_train)
    assert len(y_test) == len(X_test)

def test_missing_label_column_fails():
    with pytest.raises(ValueError, match="Label column"):
        split_features_and_labels(pd.DataFrame({"flow_duration": [1, 2]}))
