import pandas as pd
import pytest
from src.data_loader import validate_network_data

def test_valid_data_passes():
    df = pd.DataFrame({"flow_duration": [1, 2], "packet_count": [10, 20], "label": ["benign", "attack"]})
    assert validate_network_data(df).shape == (2, 3)

def test_missing_column_fails():
    df = pd.DataFrame({"flow_duration": [1], "label": ["benign"]})
    with pytest.raises(ValueError, match="packet_count"):
        validate_network_data(df)

def test_empty_data_fails():
    df = pd.DataFrame(columns=["flow_duration", "packet_count", "label"])
    with pytest.raises(ValueError, match="no records"):
        validate_network_data(df)
