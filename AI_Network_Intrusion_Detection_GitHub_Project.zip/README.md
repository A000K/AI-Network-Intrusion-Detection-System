# AI-Based Network Intrusion Detection System (NIDS)

A beginner-friendly Python project that demonstrates a machine-learning workflow for classifying labelled network-flow records as **benign** or **attack**. It includes CSV validation, a reproducible train/test split, a baseline Random Forest pipeline, evaluation metrics, prediction on new CSV files, and unit tests.

> **Important:** The included CSV is a tiny synthetic demonstration dataset, not real network traffic. Metrics from it are not evidence of real-world security performance. Replace it with a suitable, legally obtained public dataset (for example, CIC-IDS2017 or UNSW-NB15) and adapt its column names and preprocessing before drawing conclusions.

## Project structure

```text
AI_Network_Intrusion_Detection_GitHub_Project/
├── data/sample_network_flows.csv
├── models/                  # model artifact generated during training
├── reports/                 # metrics and predictions generated at runtime
├── src/
│   ├── data_loader.py
│   ├── preprocessing.py
│   ├── model.py
│   ├── train.py
│   └── predict.py
├── tests/
├── requirements.txt
└── README.md
```

## 1. Set up

Python 3.10+ is recommended. From the project root:

```bash
python -m venv .venv
```

Activate it:

- Windows PowerShell: `.venv\\Scripts\\Activate.ps1`
- macOS/Linux: `source .venv/bin/activate`

Then install dependencies:

```bash
python -m pip install -r requirements.txt
```

## 2. Train the example model

```bash
python -m src.train
```

The script trains on `data/sample_network_flows.csv`, evaluates against a held-out split, and writes:
- `models/nids_model.joblib`
- `reports/metrics.json`

The small sample dataset is only for checking that the pipeline runs. It is not suitable for assessing generalization.

## 3. Run tests

```bash
python -m pytest -q
```

Tests check basic schema validation and train/test splitting. A successful test run confirms these limited checks only; it does not prove that the detector is safe or production-ready.

## 4. Predict on new records

Create a CSV containing the same feature columns used during training (excluding `label`), then run:

```bash
python -m src.predict --input data/new_flows.csv
```

Predictions are saved to `reports/predictions.csv`. The input must contain numeric features with the same names and meanings as the training data.

## Model design

The baseline is a scikit-learn Pipeline using median imputation and a Random Forest classifier. The split is stratified to help preserve class proportions. Weighted precision, recall, F1, accuracy, a confusion matrix, and a classification report are saved after training.

For an actual intrusion-detection study, evaluate per-class precision/recall/F1, false-positive and false-negative rates, class imbalance, data leakage, dataset provenance, and performance on a separate test set. Network datasets often contain categorical fields; encode them using a fitted preprocessing pipeline rather than converting them arbitrarily. Fit all preprocessing only on training data.

## Limitations and next steps

- The schema is intentionally minimal and assumes numeric features.
- The sample data is synthetic and extremely small.
- The current model is a baseline, not a live packet-capture tool.
- It does not block traffic, connect to a firewall, or provide a production dashboard.
- Before real use, add dataset-specific preprocessing, stronger tests, model versioning, drift monitoring, security review, and an approved deployment process.

## Ethical and safe use

Use this project for learning and authorized defensive security work. Do not capture or analyze traffic without appropriate permission. Do not treat predictions as a substitute for human investigation or established security controls.
